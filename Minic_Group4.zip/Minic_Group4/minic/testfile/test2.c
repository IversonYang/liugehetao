#include <stdio.h>
void main()
{
    int n, i, sum;
    sum = 0;
    printf("Please input n: ");
    scanf("%d",&n);	
    for(i=1; i<=n; i=i+1)	
    {		
        sum = sum + i;	
    }	    
    printf("sum = %d",sum);
    
printf("\n");	
}
