#include <stdio.h>
void main()
{
    int n, i, sum;
    i = 1;
    sum = 0;
    printf("Please input n: ");
    scanf("%d",&n); 
    while(i <= n)
    {
        sum = sum + i;
        i = i + 1;	
    }	    
    printf("sum = %d",sum);
     
printf("\n");	
}
