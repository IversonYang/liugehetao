#include <stdio.h>

void main()
{
  int x, y;
  printf("Please input x and y :\n");
  scanf("%d",&x);
  scanf("%d",&y);
  int z = ( x + y * 5 ) * 4 / 3;
  printf("z = ( x + y * 5 ) * 4 / 3 = %d",z);
  printf("\n"); 
}
