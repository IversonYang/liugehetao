package com.by5.editor;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.Insets;
import java.awt.List;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.InputEvent;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.ArrayList;

import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.text.InternationalFormatter;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.*;
import javax.swing.tree.TreePath;
import org.omg.CORBA.PUBLIC_MEMBER;
import com.by5.editor.commons.AddInfo;
import com.by5.editor.commons.WorkSpace;
import com.by5.editor.frame.AddFrame;
import com.by5.editor.handler.add.AddFileHandler;
import com.by5.editor.tree.ProjectTreeModel;
import com.by5.editor.tree.ProjectTreeNode;
import com.by5.editor.tree.TreeCreator;
public class EditorFrame extends JFrame {
    private static final long serialVersionUID = 1L;
    private final int WIDTH = 800;
    private final int HEIGHT = 600;
    File file; //打开的文件
    String dir; // 存放路径
    static JTabbedPane tabPane;
    static Box box; // 编辑代码的窗口
    static JDesktopPane desk;
    static JSplitPane editorSplitPane;
    static JScrollPane infoPane; // 右下角的输出信息的窗口
    static JTextArea infoArea;
    static JTextPane pane;
    static String text = null;
    static JScrollPane treePane;
    static JSplitPane mainSplitPane;
    static JTree tree;
    private Action fileNew = new AbstractAction("analyse", new ImageIcon("images/newFile.gif")) {
        public void actionPerformed(ActionEvent e) {
        	try {
                TestLexer testLexer = new TestLexer("./src/input.c");
        		testLexer.analyse();
                // 读取生成的文件，并输出到信息栏
                file = new File("./src/output.txt");
                FileInputStream fis = new FileInputStream(file);
                BufferedReader br = new BufferedReader(new InputStreamReader(fis));
                text = "";
                int ch;
                while ((ch = br.read()) != -1) {
                    text += (char)ch;
                }
                System.out.println(text);   
                JTextPane infoPane = new JTextPane();
                infoPane.setText(text);
                infoPane.setEditable(true);
                infoPane.setVisible(true);
                infoPane.getDocument().addDocumentListener(new Highlighting(infoPane));
                // infoPane并没有什么作用
                infoArea.setBackground(Color.white);
                infoArea.setText(text);
                infoArea.add(infoPane, CENTER_ALIGNMENT);
                infoArea.setVisible(true);

            } catch (Exception e1) {
                e1.printStackTrace();
            }
        }
    };
    private Action folerNew = new AbstractAction("compile", new ImageIcon("images/refresh.gif")) {
        public void actionPerformed(ActionEvent e) {
        	try {
        		//fan bian yi 
        	String command = "gcc -S -o" + " " + "./src/input.s"+" "+"./src/input.c";
        		Process process = Runtime.getRuntime().exec(command); 
              file = new File("./src/input.s");
              FileInputStream fis = new FileInputStream(file);
              BufferedReader br = new BufferedReader(new InputStreamReader(fis));
              text = "";
              int ch;
              while ((ch = br.read()) != -1) {
                  text += (char)ch;
              }
              System.out.println(text);   
              JTextPane infoPane = new JTextPane();
              infoPane.setText(text);
              infoPane.setEditable(true);
              infoPane.setVisible(true);
              infoPane.getDocument().addDocumentListener(new Highlighting(infoPane));
              // infoPane并没有什么作用
              infoArea.setBackground(Color.white);
              infoArea.setText(text);
              infoArea.add(infoPane, CENTER_ALIGNMENT);
              infoArea.setVisible(true);
          } catch (Exception e1) {
              FileInputStream fis = null;
			try {
				fis = new FileInputStream(new File("./src/input.txt"));
			} catch (FileNotFoundException e2) {
				// TODO Auto-generated catch block
				e2.printStackTrace();
			}
              BufferedReader br = new BufferedReader(new InputStreamReader(fis));
              text = "";
              int ch;
              try {
				while ((ch = br.read()) != -1) {
				      text += (char)ch;
				  }
			} catch (IOException e2) {
				// TODO Auto-generated catch block
				e2.printStackTrace();
			}
              System.out.println(text);
              JTextPane infoPane = new JTextPane();
              infoPane.setText(text);
              infoPane.setEditable(true);
              infoPane.setVisible(true);
              infoPane.getDocument().addDocumentListener(new Highlighting(infoPane));
              // infoPane并没有什么作用
              infoArea.setBackground(Color.white);
              infoArea.setText(text);
              infoArea.add(infoPane, CENTER_ALIGNMENT);
              infoArea.setVisible(true);
              e1.printStackTrace();
          }
        }
    };
    private Action projectNew = new AbstractAction("run", new ImageIcon("images/newFile.gif")) {
        public void actionPerformed(ActionEvent e) {
        	String command = "gnome-terminal -x bash -c ./src/test;read";
        	
        	String command1 = "gcc -o ./src/test"+" "+"./src/input.c";
            try {
            	Process process1 = Runtime.getRuntime().exec(command1);
            	Process process2 = Runtime.getRuntime().exec(command);
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} 
        }
    };
    private Action open = new AbstractAction("tree", new ImageIcon("images/open.gif")) {
        public void actionPerformed(ActionEvent e) {
        	 try {
             	String command = "lexyantree " + file.toString();
                 Process process = Runtime.getRuntime().exec(command); 
                 file = new File("/home/dr/minic1/minic/testfile/treeoutput");
                 FileInputStream fis = new FileInputStream(file);
                 BufferedReader br = new BufferedReader(new InputStreamReader(fis));
                 text = "";
                 int ch;
                 while ((ch = br.read()) != -1) {
                     text += (char)ch;
                 }
                 infoArea.setBackground(Color.white);
                 infoArea.setText(text);
                 System.out.println(text);
             } catch (IOException er) {
                 er.printStackTrace();
             }
        }
    };
    private Action save = new AbstractAction("save", new ImageIcon("images/save.gif")) {
        public void actionPerformed(ActionEvent e) {
            try {
                FileOutputStream fos = new FileOutputStream("./src/input.c");
                BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(fos));
                text = pane.getText();
                bw.write(text);
                bw.close();
                tree.updateUI();
            } catch (Exception e2) {
                e2.printStackTrace();
            }
        }
    };
 
    private JMenuBar menuBar;
    private JMenu editMenu;
    private JMenu fileMenu;
    private JMenu projMenu;
    private JToolBar toolBar;
    private WorkSpace workSpace;
    private TreeCreator treeCreator;
    private AddFrame addFrame;
    public EditorFrame(TreeCreator treeCreator) {
        super();
        this.treeCreator = treeCreator;
        this.setTitle("MiniC_Group4");
    }
    public void initFrame(WorkSpace space) {
        this.workSpace = space;
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        tabPane = new JTabbedPane(JTabbedPane.TOP, JTabbedPane.SCROLL_TAB_LAYOUT);
        desk = new JDesktopPane();
        desk.setBackground(Color.GREEN);
        box = new Box(BoxLayout.PAGE_AXIS);
        pane = new JTextPane();
        
        box.add(new JScrollPane(pane)); 
        pane.getDocument().addDocumentListener(new Highlighting(pane));
        pane.setFont(new Font("YaHei Consolas Hybrid", Font.PLAIN, 20));//set cin font
        pane.setBackground(Color.black);//here

        pane.setBorder(new LineNumberBorder());
        
        //set printf area
        infoArea = new JTextArea("", 10, 50);
        infoPane = new JScrollPane(infoArea);
        infoArea.setEditable(false);
        infoArea.setBackground(Color.WHITE);//printf color
        editorSplitPane = new JSplitPane(JSplitPane.VERTICAL_SPLIT, box, infoPane);
        editorSplitPane.setDividerSize(3);
        editorSplitPane.setDividerLocation(400);
        this.add(editorSplitPane);

        tree = treeCreator.createTree(this);
        treePane = new JScrollPane(tree);
        treePane.setBackground(Color.black);//
        mainSplitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, treePane, editorSplitPane);
        mainSplitPane.setDividerLocation(200);
        mainSplitPane.setDividerSize(3);
        mainSplitPane.setBackground(Color.darkGray);
        this.add(mainSplitPane);

        createMenuBar();
        createToolBar();
        // tree = treeCreator.createTree(this);
        addListeners();
        this.setSize(this.WIDTH, this.HEIGHT);
        this.setLocation(200, 75);
    }
    private void createToolBar() {
        toolBar = new JToolBar();
        toolBar.setFloatable(false);
        toolBar.setMargin(new Insets(0, 10, 5, 5));
        this.add(toolBar, BorderLayout.NORTH);
    }
    public void openFile(Object object){
          try {
              file = new File(workSpace.getFolder().toString() + "/" + object.toString());
              FileInputStream fis = new FileInputStream(file);
              BufferedReader br = new BufferedReader(new InputStreamReader(fis));
              text = "";
              int ch;
              while ((ch = br.read()) != -1) {
                  text += (char)ch;
              }
              System.out.println(text);
              pane.setText(text);
              pane.setEditable(true);
              pane.setCaretColor(Color.RED); //设置光标的颜色为白色
              pane.setVisible(true);
//              box.remove(desk);
//              box.add(new JScrollPane(pane));
          } catch (Exception e) {
              e.printStackTrace();
          }
    }
    private void addListeners(){
		fileMenu.add(fileNew).setAccelerator(KeyStroke.getKeyStroke('N', InputEvent.CTRL_MASK));
		fileMenu.add(folerNew).setAccelerator(KeyStroke.getKeyStroke('F', InputEvent.CTRL_MASK));
		fileMenu.add(projectNew).setAccelerator(KeyStroke.getKeyStroke('P', InputEvent.CTRL_MASK));
		fileMenu.add(open).setAccelerator(KeyStroke.getKeyStroke('O', InputEvent.CTRL_MASK));
		fileMenu.add(save).setAccelerator(KeyStroke.getKeyStroke('S', InputEvent.CTRL_MASK));
	
		tree.addTreeSelectionListener(new TreeSelectionListener() {
            @Override
            public void valueChanged(TreeSelectionEvent e) {
                DefaultMutableTreeNode node = (DefaultMutableTreeNode) tree
                        .getLastSelectedPathComponent();
                if (node == null)
                    return;
                Object object = node.getUserObject();
                if (node.isLeaf()) {
                    openFile(object);
                }
 
            }
        });
		toolBar.add(fileNew).setToolTipText("新建");
		toolBar.add(open).setToolTipText("打开");
		toolBar.add(save).setToolTipText("保存");
		toolBar.addSeparator();


	}
    private void createMenuBar() {
        menuBar = new JMenuBar();
        fileMenu = new JMenu("file");
        editMenu = new JMenu("edit");
        projMenu = new JMenu("proj");
        menuBar.add(fileMenu);
        menuBar.add(editMenu);
        menuBar.add(projMenu);
        this.setJMenuBar(menuBar);
    }
    public WorkSpace getWorkSpace() {
        return workSpace;
    }
    public ProjectTreeNode getSelectNode() {
        TreePath path = tree.getSelectionPath();
        if (path != null) {
            ProjectTreeNode selectNode = (ProjectTreeNode) path.getLastPathComponent();
            return selectNode;
        }
        return null;
    }

    public void newFile() {
        AddInfo info = new AddInfo("新建项目", this, new AddFileHandler());
        showAddFrame(info);
    }

    private void showAddFrame(AddInfo info) {
        setEnabled(false);
        addFrame = new AddFrame(info);
        addFrame.pack();
        addFrame.setVisible(true);
    }

    // public void reloadNode(ProjectTreeNode selectNode) {
    // if (selectNode == null) return;
    // ProjectTreeModel model = (ProjectTreeModel)getTree().getModel();
    // model.reload(selectNode, treeCreator);
    // }

}
