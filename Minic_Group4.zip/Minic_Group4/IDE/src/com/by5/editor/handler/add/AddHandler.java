package com.by5.editor.handler.add;

import com.by5.editor.EditorFrame;
import com.by5.editor.frame.AddFrame;

public interface AddHandler {
	void afterAdd(EditorFrame editorFrame,AddFrame addFrame,Object data);
}
