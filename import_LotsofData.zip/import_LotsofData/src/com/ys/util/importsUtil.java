package com.ys.util;

import java.awt.List;
import java.io.*;
import java.util.*;

import com.google.common.collect.Lists;

import jxl.*;

import  java.util.ArrayList;

 /**        
 * Title: importsUtil    
 * Description: Excel的批量导入类
 * @author IversonYang      
 * @created 2017年3月26日   
 */
public class importsUtil {
	
	public static java.util.List<HashMap<String,String>> readExcel(String excelUrl){
		//声明一个list数组用于保存解析出来的内容
		java.util.List<HashMap<String,String>> lists = new ArrayList<HashMap<String,String>>();
		try {
			//定义一个文件流读取Excel文件
			InputStream is = new FileInputStream(excelUrl);
			//获取Excel文件对象
			 Workbook wb = Workbook.getWorkbook(is);
			 //获取excel文件sheet（默认第一个）
			 Sheet sheet = wb.getSheet(0);
			 //或者行和列
			 int rows = sheet.getRows();
			 int cols = sheet.getColumns();
			 for(int i=0;i<rows;i++){
				//循环读取每一行的内容
				 Cell[] cells = sheet.getRow(i);
				 String leixing = cells[0].getContents();
				 String banji = cells[1].getContents();
				 
				 HashMap<String, String> map = new HashMap<String, String>();
				 map.put("leixing",leixing);
				 map.put("banji",banji);
				 //将map保存到list集合中
				 lists.add(map);
			 }
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return lists;
	}
	
	public static void main(String[] args){
		//获取Excel文件的地址
//		String excelUrl = "G:\\My_Life\\我的班级\\ACM志愿者\\计算机1401班志愿者报名表.xls";
//		//声明一个list数组用于保存解析出来的内容
//		java.util.List<HashMap<String,String>> lists = new ArrayList<HashMap<String,String>>();
//		
//		try {
//			//定义一个文件流读取Excel文件
//			InputStream is = new FileInputStream(excelUrl);
//			//获取Excel文件对象
//			 Workbook wb = Workbook.getWorkbook(is);
//			 //获取excel文件sheet（默认第一个）
//			 Sheet sheet = wb.getSheet(0);
//			 //或者行和列
//			 int rows = sheet.getRows();
//			 int cols = sheet.getColumns();
//			 for(int i=0;i<rows;i++){
//				//循环读取每一行的内容
//				 Cell[] cells = sheet.getRow(i);
//				 String leixing = cells[0].getContents();
//				 String banji = cells[1].getContents();
//				 
//				 HashMap<String, String> map = new HashMap<String, String>();
//				 map.put("类别",leixing);
//				 map.put("班级",banji);
//				 //将map保存到list集合中
//				 lists.add(map);
//			 }
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//		System.out.println(lists);
		
	}
}
